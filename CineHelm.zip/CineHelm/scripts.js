// scripts.js
const carousel = document.getElementById('movieCarousel');
    const scrollAmount = 300; // Set the amount to scroll with each button click

    document.getElementById('scrollLeft').addEventListener('click', () => {
        carousel.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });
    });

    document.getElementById('scrollRight').addEventListener('click', () => {
        carousel.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });
    });
    
// Event listener for when a carousel image is clicked
document.querySelectorAll('.carousel-item img').forEach(item => {
    item.addEventListener('click', function() {
        // Get the data attributes from the clicked image
        const trailerUrl = this.getAttribute('data-trailer');
        const movieTitle = this.getAttribute('data-title');
        const movieDescription = this.getAttribute('data-description');
        
        // Set the video source and description in the modal
        document.getElementById('trailerVideo').src = trailerUrl;
        document.getElementById('movieTitle').textContent = movieTitle;
        document.getElementById('movieDescription').textContent = movieDescription;
        
        // Ensure the video starts playing when the modal is shown
        const videoElement = document.getElementById('trailerVideo');
        videoElement.load();  // Load the new video
        videoElement.play();  // Play the video automatically
    });
});

// Close video and reset when the modal is closed
document.getElementById('trailerModal').addEventListener('hidden.bs.modal', function () {
    const videoElement = document.getElementById('trailerVideo');
    videoElement.pause();  // Pause the video
    videoElement.currentTime = 0;  // Reset video to the beginning
});
