<?php
$movies = [
    ["title" => "Movie 1", "image" => "movies/Sonic3.jpg", "trailer" => "trailers/sonic3.mp4", "description" => "This is the description for Movie 1."],
    ["title" => "Movie 2", "image" => "movies/DP3.jpg", "trailer" => "trailers/trailer2.mp4", "description" => "This is the description for Movie 2."],
    ["title" => "Movie 3", "image" => "movies/Wicked.jpg", "trailer" => "trailers/trailer3.mp4", "description" => "This is the description for Movie 3."],
    ["title" => "Movie 4", "image" => "movies/FallGuy1.jpg", "trailer" => "trailers/trailer4.mp4", "description" => "This is the description for Movie 4."],
    ["title" => "Movie 5", "image" => "movies/newempire.jpg", "trailer" => "trailers/trailer5.mp4", "description" => "This is the description for Movie 5."],
    ["title" => "Movie 6", "image" => "movies/monke.jpg", "trailer" => "trailers/trailer6.mp4", "description" => "This is the description for Movie 6."],
    ["title" => "Movie 7", "image" => "movies/bond.jpg", "trailer" => "trailers/bondmov.mp4", "description" => "This is the description for Movie 7."],
    ["title" => "Movie 8", "image" => "movies/strange.jpg", "trailer" => "trailers/trailer8.mp4", "description" => "This is the description for Movie 8."],
    ["title" => "Movie 9", "image" => "movies/moana2.jpg", "trailer" => "trailers/trailer9.mp4", "description" => "This is the description for Movie 9."],
    ["title" => "Movie 10", "image" => "movies/mine.jpg", "trailer" => "trailers/trailer10.mp4", "description" => "This is the description for Movie 10."]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CineHelm</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="bg-dark text-white text-center py-4">
        <h1>CINEHELM</h1>
        <p>Navigate your Movie Experience!</p>
    </header>

    <div class="container mt-4">
    <div class="carousel-container position-relative">
        <!-- Left Navigation Button -->
        <button class="carousel-nav left" id="scrollLeft">
            &lt;
        </button>

        <!-- Horizontal Scrollable Movie Carousel -->
        <div id="movieCarousel" class="movie-carousel">
            <?php
            foreach ($movies as $movie):
            ?>
                <div class="movie-item">
                    <img src="<?php echo $movie['image']; ?>" class="d-block" alt="<?php echo $movie['title']; ?>" 
                         data-bs-toggle="modal" data-bs-target="#trailerModal" 
                         data-trailer="<?php echo $movie['trailer']; ?>" 
                         data-title="<?php echo $movie['title']; ?>" 
                         data-description="<?php echo $movie['description']; ?>" />
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Right Navigation Button -->
        <button class="carousel-nav right" id="scrollRight">
            &gt;
        </button>
    </div>
</div>

    <!-- Trailer Modal with Description -->
    <div class="modal fade" id="trailerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="movieTitle">Trailer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body d-flex">
                    <!-- Video section on the left -->
                    <div class="video-container" style="flex: 2;">
                        <video id="trailerVideo" controls style="width: 100%;"></video>
                    </div>

                    <!-- Movie Description on the right -->
                    <div class="description-container" style="flex: 1; padding-left: 20px;">
                        <h4>Description</h4>
                        <p id="movieDescription"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="scripts.js"></script>
</body>
</html>